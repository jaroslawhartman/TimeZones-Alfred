source includes.sh

FORMAT="$1"

storePreference "TIME_FORMAT" "$FORMAT"